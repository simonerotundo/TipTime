package com.example.tiptime

import android.content.Context
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.InputMethodManager
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat.getSystemService
import com.example.tiptime.databinding.ActivityMainBinding
import java.text.NumberFormat

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.calculateButton.setOnClickListener { calculateTip() }

    }

    private fun calculateTip() {

        /** Viene invocata quando si fa click sul pulsante "CALCULATE" **/

        val stringInTextField = binding.costOfServiceEditText.text.toString()   // converto il testo contenuto in "costOfService" in una stringa
        val cost = stringInTextField.toDoubleOrNull()                           // converto la stringa in un dato di tipo double o null

        /* se la stringa è vuota (l'utente non ha inserito un valore) .. */
        if (cost == null) {
            binding.tipResult.text = ""     // imposto una stringa vuota come risultato, in modo da non confondere l'utente
            return                          // restituisco il controllo così da non mandare in crash l'applicazione
        }

        /* memorizzo la percentuale di mancia in base alla qualità del servizio */
        val tipPercentage = when (binding.tipOptions.checkedRadioButtonId) {
            R.id.option_twenty_percent -> 0.20
            R.id.option_eighteen_percent -> 0.18
            else -> 0.15
        }

        var tip = tipPercentage * cost  // calcolo la mancia

        /* se l'opzione per arrotondare la mancia è selezionata .. */
        if (binding.roundUpSwitch.isChecked) {
            tip = kotlin.math.ceil(tip)     // arrotondo la mancia
        }

        val formattedTip = NumberFormat.getCurrencyInstance().format(tip)       // formatto il numero
        binding.tipResult.text = getString(R.string.tip_amount, formattedTip)   // imposto il testo della mancia da pagare
    }
}